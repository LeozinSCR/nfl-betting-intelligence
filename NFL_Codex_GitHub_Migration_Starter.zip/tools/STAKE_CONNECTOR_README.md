# Stake Odds — NFL Betting Intelligence (read-only)

Esse conector consulta a **API pública oficial de dados esportivos** documentada em https://sportsbook-api.stake.com/ . Não acessa sua conta, não consulta saldo e **nunca faz apostas**. Exige acesso de rede externo na máquina onde for executado.

## Executar

Requer Python 3.9+; usa apenas biblioteca-padrão.

```bash
python stake_odds.py --out cotacoes_stake
```

Sem chave: máximo 4 requisições/hora conforme a documentação. O script usa até três: esportes, torneios e partidas. Se não aparecer NFL na primeira página dos torneios, salve o ID encontrado no JSON e execute uma nova consulta com `--sport-id` e `--tournament-id`, dentro da cota. Com uma **chave oficial de afiliado**, defina a variável de ambiente `SPORTSBOOK_API_KEY` localmente; não envie essa chave no chat.

Arquivos gerados: `stake_raw.json` (snapshot integral) e `stake_offers.csv` (melhor esforço de normalização de mercados e seleções). Envie esses arquivos para o ChatGPT para cruzamento com nosso modelo. A documentação não garante que todos os player props estejam disponíveis; cheque os `offers` reais. Não use odds antigas para apostar.

## Restrições

- O código ainda não foi testado contra o servidor ao vivo, pois o ambiente da conversa não conseguiu resolver o host da Stake.
- Não existe integração persistente nativa ao chat por instalar este script.
- O script lê só a primeira página em cada nível para respeitar o limite público de chamadas.
- Odds e disponibilidade mudam; confirme no app antes de qualquer aposta.
- Não forneça credenciais, cookies de sessão nem tokens pessoais neste chat.
