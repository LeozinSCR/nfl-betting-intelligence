# Fontes externas, licenças e verificações

| Fonte | Interface | Dados | Custo/licença | Observações |
|---|---|---|---|---|
| nflverse | nflreadpy / GitHub releases | PBP, player stats, snaps, injuries, schedules, roster | A maioria CC-BY 4.0; datasets especiais podem diferir | Fonte principal, releases disponibilizadas com defasagem, cobertura precisa ser validada |
| Sleeper | https://api.sleeper.app/v1/players/nfl | Jogadores, times, status, IDs e injuries | Grátis para uso não comercial, sem token | Snapshot no máximo diário, status não substitui inativos oficiais |
| NFL | https://www.nfl.com/ | injury reports, actives/inactives, schedule | Consulta pública; verificar licenças | Confirmar disponibilidade pré-jogo |
| Stake | https://sportsbook-api.stake.com/ | Eventos/linhas/odds publicadas | Documentação pública, limites sem chave | Conector experimental; nunca comprovado ao vivo neste ambiente; usar apenas read-only |

**Não considerar a API da ESPN como oficial/estável.** Não distribuir dados sem respeitar licença; não usar qualquer endpoint que necessite burlar login, anti-bot ou bloqueios regionais.

## Identidade e qualidade
- Cruzar jogadores por identificadores (GSIS/PFR/Sleeper) com tabela versionada; nunca confiar somente em nome.
- Registrar período, data de captura, checksum, número de registros, URL de origem e ausência/duplicidade por time e semana.
- Distinguir `inactive`, `active_zero_offense_snaps`, `active_offensive_snaps_no_touch`, `offensive_touch`, `unknown`.
- Snapshot histórico congelado antes de cada jogo para evitar information leakage.
- Aplicar teste de legalidade: conversões de 2 pontos não contam como targets/carries convencionais.

## Links
- https://nflreadpy.nflverse.com/api/load_functions/
- https://github.com/nflverse/nflverse-data
- https://docs.sleeper.com/
- https://sportsbook-api.stake.com/
