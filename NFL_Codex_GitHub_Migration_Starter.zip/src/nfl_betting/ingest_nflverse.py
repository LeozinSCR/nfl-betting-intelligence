"""Free nflverse data ingestion. No scraped/authenticated endpoints.

Snapshots are immutable once written; names contain UTC timestamp.
Never join model predictions to source observations with timestamps later than the event cutoff.
"""
import argparse, datetime as dt, hashlib, json, pathlib, sys

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--season',type=int,default=2026)
    p.add_argument('--out',default='data/raw_auto')
    p.add_argument('--sources',nargs='+',default=['schedules','player_stats','pbp','snap_counts','injuries','rosters_weekly'])
    a=p.parse_args()
    import nflreadpy as nfl
    now=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    out=pathlib.Path(a.out)/str(a.season)/now;out.mkdir(parents=True,exist_ok=True)
    funcs={
      'schedules':lambda:nfl.load_schedules([a.season]),
      'player_stats':lambda:nfl.load_player_stats([a.season],summary_level='week'),
      'pbp':lambda:nfl.load_pbp([a.season]),
      'snap_counts':lambda:nfl.load_snap_counts([a.season]),
      'injuries':lambda:nfl.load_injuries([a.season]),
      'rosters_weekly':lambda:nfl.load_rosters_weekly([a.season]),
    }
    manifest={'season':a.season,'fetched_at_utc':now,'status':{},'sources':{}}
    failed=0
    for name in a.sources:
        if name not in funcs:raise ValueError('Unknown source: '+name)
        try:
            table=funcs[name]()
            if table is None or table.is_empty():raise ValueError('Empty dataset; current season may not be available')
            dest=out/(name+'.parquet');table.write_parquet(dest)
            sha=hashlib.sha256(dest.read_bytes()).hexdigest()
            manifest['sources'][name]={'rows':table.height,'columns':table.columns,'sha256':sha,'path':str(dest)}
            manifest['status'][name]='OK'
            print('OK',name,table.height)
        except Exception as ex:
            failed+=1;manifest['status'][name]='ERROR: '+str(ex)
            print('ERROR',name,ex,file=sys.stderr)
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf8')
    if failed:sys.exit(2)
if __name__=='__main__':main()
