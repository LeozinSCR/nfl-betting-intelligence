"""Business gates only: no invented markets/probabilities or auto-betting."""
from collections import Counter

def validate_best_parlay(legs):
    """Leg fields: game_id, player_id, market, available, is_player_prop."""
    if len(legs) < 8: return False, 'MIN_EIGHT_LEGS'
    count=Counter(x['game_id'] for x in legs)
    if len(count)<4: return False, 'MIN_FOUR_GAMES'
    if any(v<2 for v in count.values()):return False,'MIN_TWO_PER_GAME'
    if any(not x.get('is_player_prop') for x in legs):return False,'PLAYER_PROPS_ONLY'
    if any(not x.get('available') for x in legs):return False,'MARKET_UNAVAILABLE'
    if any(x.get('injury_status') in ('OUT','IR') for x in legs):return False,'INELIGIBLE_PLAYER'
    return True,'STRUCTURAL_ONLY_NO_EV_APPROVAL'

def validate_td_parlay(legs, games_that_day):
    if not games_that_day or games_that_day<1: return False,'MISSING_SCHEDULE'
    need=2 if games_that_day==1 else 4
    if len(legs)<need:return False,'TOO_FEW_TDS'
    count=Counter(x['game_id'] for x in legs)
    if games_that_day>1 and (len(count)<2 or any(n>2 for n in count.values())):
        return False,'TD_DISTRIBUTION_VIOLATION'
    if any(x.get('market')!='anytime_td' for x in legs): return False,'TD_MARKET_ONLY'
    if any(x.get('injury_status') in ('OUT','IR') for x in legs):return False,'INELIGIBLE_PLAYER'
    return True,'STRUCTURAL_ONLY_NO_EV_APPROVAL'

def implied_probability(decimal_odds):
    if decimal_odds is None or decimal_odds <= 1:raise ValueError('Decimal odds > 1 required')
    return 1/decimal_odds

def expected_value(probability, decimal_odds, calibrated=False, price_verified=False):
    if not (calibrated and price_verified):raise PermissionError('EV blocked: requires calibration and verified real price')
    if not 0<=probability<=1:raise ValueError('Probability out of bounds')
    return probability*decimal_odds-1
