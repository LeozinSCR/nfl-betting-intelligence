import unittest
from src.nfl_betting.rules import validate_best_parlay,validate_td_parlay, expected_value

def leg(g,i):return {'game_id':g,'player_id':f'player{i}','market':'receptions','is_player_prop':True,'available':True}
class RuleTests(unittest.TestCase):
    def test_minimum_is_eight_in_four_games(self):
        eight=[leg(g,i) for g in range(4) for i in range(2)]
        self.assertTrue(validate_best_parlay(eight)[0])
        self.assertFalse(validate_best_parlay(eight[:-1])[0])
    def test_out_blocks(self):
        legs=[leg(g,i) for g in range(4) for i in range(2)]
        legs[0]['injury_status']='IR'
        self.assertFalse(validate_best_parlay(legs)[0])
    def test_td_distribution(self):
        four=[dict(game_id=i,market='anytime_td') for i in range(4)]
        self.assertTrue(validate_td_parlay(four,13)[0])
    def test_ev_gate(self):
        with self.assertRaises(PermissionError): expected_value(.7,1.8)
if __name__=='__main__':unittest.main()
