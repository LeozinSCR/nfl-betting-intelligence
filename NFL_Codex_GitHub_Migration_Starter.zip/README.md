# NFL Betting Intelligence — Codex Migration (starter)

Este projeto é uma MIGRAÇÃO INICIAL AUDITÁVEL de dados e políticas do trabalho feito no ChatGPT. Não é um bot de apostas aprovado, nem disponibiliza odds em tempo real nesta versão.

## O que vem no pacote
- `legacy/` Master V1.1 fase 33 e relatório de Semana 10, preservados como artefatos originais
- `data/processed/` recortes CSV reconciliados e resultados de backtest; **não são dados ao vivo**
- `tools/stake_odds.py` protótipo read-only não verificado contra servidor ao vivo
- `src/nfl_betting/ingest_nflverse.py` coletor gratuito usando nflreadpy
- `src/nfl_betting/rules.py` regras de negócios e testes sem odds inventadas
- `.github/workflows/weekly_refresh.yml` rotina semanal com PR, sujeita a habilitação GitHub Actions e permissões
- `docs/CODEX_HANDOFF.md` prompt completo para Codex
- `docs/DATA_SOURCES.md` matriz de fontes, atualização, licença e limites
- `docs/FILE_MANIFEST.json` inventário de arquivos incluídos com SHA-256

## Instalação (PC ou Codex Cloud)
```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m src.nfl_betting.ingest_nflverse --season 2026 --out data/raw_auto
```
O import usa `nflreadpy` (Polars); não requer senha de NFL. A execução necessita internet e o feed de 2026 pode sofrer atraso ou indisponibilidade.

## Regras centrais
- Orçamento de R$ 50 por rodada, sendo **R$ 35 Best Parlay** e **R$ 15 TD Parlay** como teto, não obrigação.
- Best Parlay: no mínimo **4 jogos distintos**, ao menos **2 player props por jogo**, **mínimo 8 legs**. Pode expandir com evidência de valor.
- TD Parlay: 4 TDs se dia tiver 2+ jogos (1-2 por jogo) ou 2 TDs para dia com um jogo.
- Excluir seleções de equipes com mudanças críticas de QB/uso sem modelagem própria; adversários permanecem elegíveis.
- Sem jogador IR/OUT, odds inventadas, rankings por histórico puro, leakage de dados pós-jogo, nem EV aprovado sem probabilidades calibradas e preço comparável.

## Próximas tarefas de engenharia
1. Importar `NFL_historical_sources_2026.zip` opcional para o diretório `data/raw/` (fora do Git se grande).
2. Testar redes, cobertura, schemas e ID crosswalk (GSIS/PFR/Sleeper) para 2026.
3. Verificar dados prospectivos com `event_time`, `ingested_at_utc`, `prediction_asof_utc`.
4. Adicionar ingestão de odds Stake verificadas, sem credenciais pessoais e com limites de taxa.
5. Criar dashboard mobile ou publicar relatórios via GitHub/Pages após validação.

## Segredos
Nunca commitar senhas, chaves ou tokens; usar GitHub Actions Secrets quando necessário. Conector Stake é somente leitura.
